**Selected Publications (3)**
- **Nie, L.**, Chen, Y., Du, M., Sun, C. & Zhang, D.. A knowledge-based data-driven (KBDD) framework for all-day identification of cloud types using satellite remote sensing. *Remote Sensing of Environment*, 2024, 304: 114054. https://doi.org/10.1016/j.rse.2024.114054
- **Nie, L.**, Chen, Y., Zhang, D., Liu, X. & Yuan, W.. QIENet: Quantitative irradiance estimation network using recurrent neural network based on satellite remote sensing data. *International Journal of Applied Earth Observation and Geoinformation*, 2024, 127: 103584. https://doi.org/10.1016/j.jag.2023.103584
- **聂隆锋**, 赵西增, 张志杭, 等. 基于VPM-THINC/QQ模型的波浪高保真模拟. *力学学报*, 2019, 51(04): 1043-1053.

&nbsp;

**In Review (1)**
- **Nie, L.**, Chen, Y., Zhang, D.. Retrieval of all-day cloud property based on the satellites Himawari-8/9. *Scientific Data*, 2023, In review.

&nbsp;

**2024 (2)**
- **Nie, L.**, Chen, Y., Du, M., Sun, C. & Zhang, D.. A knowledge-based data-driven (KBDD) framework for all-day identification of cloud types using satellite remote sensing. *Remote Sensing of Environment*, 2024, 304: 114054. https://doi.org/10.1016/j.rse.2024.114054
- **Nie, L.**, Chen, Y., Zhang, D., Liu, X. & Yuan, W.. QIENet: Quantitative irradiance estimation network using recurrent neural network based on satellite remote sensing data. *International Journal of Applied Earth Observation and Geoinformation*, 2024, 127: 103584. https://doi.org/10.1016/j.jag.2023.103584

&nbsp;

**Before 2024 (5)**
- 赵西增, **聂隆锋**, 殷铭简. 一种高保真超长黏性数值波浪水槽. *水动力学研究与进展(A辑)*, 2020, 35(01): 23-30.
- 赵西增, 童晨奕, 徐天宇, **聂隆锋**. 闸门运动对溃坝波越堤过程的影响研究. *华中科技大学学报(自然科学版)*, 2019, 47(06): 79-85.
- **聂隆锋**, 赵西增, 张志杭, 等. 基于VPM-THINC/QQ模型的波浪高保真模拟. *力学学报*, 2019, 51(04): 1043-1053.
- Zhang, Z., Zhao, X., Xie B., **Nie, L.**. High-fidelity simulation of regular waves based on multi-moment finite volume formulation and THINC method. *Applied Ocean Research*, 2019, 87: 81-94. https://doi.org/10.1016/j.apor.2019.03.007
- 蒋永强, 杨忠勇, 石小涛, 吴磊, **聂隆锋**, 等. 基于多重水力学因子的竖缝式鱼道中鱼类上溯轨迹模拟. *生态学杂志*, 2018, 37(04): 1282-1290.

&nbsp;