# CldNet

![cloud property](/images/cloudproperty.png "Demo")

&nbsp;

## Cloud Property (all-day)

| Keyword      |                                                         Description                                                          |
| :----------- | :--------------------------------------------------------------------------------------------------------------------------: |
| ⚓ File type  |                                                            NetCDF                                                            |
| 💎 Version    |                                                            2.0.0                                                             |
| 🌏 Coverage   |                                                 80°E ~ 160°W and 60°N ~ 60°S                                                 |
| 🏁 Resolution |                                                        0.05° X 0.05°                                                         |
| 🌅 Variables  | Cloud types (ISCCP Definition), Cloud optical thickness, Cloud top temperature, Cloud top height, and Cloud effective radius |
| 🏡 Code       |                   Github: [https://github.com/metdai/PMD-CldNetV2](https://github.com/metdai/PMD-CldNetV2)                   |

&nbsp;

&nbsp;


## **More data coming soon...** 🚀

If you need them and have any questions, please feel free to contact me via email metdai@outlook.com .

We really hope this database will be helpful to you. 🎏🐳

&nbsp;

&nbsp;

<!-- <font face="微软雅黑" size=5 color="Fuchsia">
We really hope this database will be helpful to you.
🎏🐳
</font>



<br />
<br />
<div align=center>
<a href="https://www.revolvermaps.com/livestats/5sy84ms7doq/"><img src="//rf.revolvermaps.com/h/m/a/0/ff0000/128/15/5sy84ms7doq.png" width="256" height="128" alt="Map" style="border:0;"></a>
</div> -->