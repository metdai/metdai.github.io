# 确保脚本抛出遇到的错误
set -e

# 生成静态文件
# flet build web --no-web-splash
flet publish ./main.py --app-name "METDAI" --app-short-name "METDAI" --app-description "METhod Descriptor with Artifical Intelligence" --use-color-emoji
echo "------publish completed------"

# 拷贝相关配置和资源
cp -f manifest.json dist/
cp -r assets/. dist/
echo "------copy completed------"
# 修改网页标题
sed -i '25s/Flet/METDAI/g' dist/index.html

# # 本地查看
# # python -m http.server --directory build/web
# python -m http.server --directory dist
# echo "http://localhost:8000/"

# 进入生成的文件夹
# cd build/web
cd dist

# 构建CNAME文件，用于连接个人域名
touch CNAME
echo "www.metdai.com" > CNAME

# 构建仓库
git init
git add -A
git commit -m "deploy"

# 发布到自己的代码仓库用于展示
# 需要注意的是本地电脑要有推送代码到仓库的权限，一般在本地生成密钥，在远程仓库设置访问权限
git push -f github_metdai:metdai/metdai.github.io.git

echo "METDAI网址如下"
# echo "https://metdai.github.io"
echo "https://www.metdai.com"