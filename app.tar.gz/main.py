import flet as ft
import time

with open("docs/CldNet.md", "r", encoding="UTF-8") as f:
    md_CldNet = f.read()


def main(page: ft.Page):
    print("Default page height:", page.height)
    page.padding = 0
    page.spacing = 0
    page.scroll = ft.ScrollMode.AUTO

    homebar = ft.Container(
        content=ft.Row(
            [
                ft.Text(
                    "METDAI",
                    size=30,
                    color="pink600",
                    bgcolor=ft.colors.AMBER_200,
                    italic=True,
                )
            ],
            alignment=ft.MainAxisAlignment.SPACE_AROUND,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        height=60,
        bgcolor=ft.colors.WHITE60,
    )

    homebg = ft.Container(
        content=ft.Row(
            [
                ft.Image(
                    src=f"/icon.png",
                    width=350,
                    height=350,
                    fit=ft.ImageFit.CONTAIN,
                ),
                # ft.Text(
                #     "METDAI",
                #     size=100,
                # ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_AROUND,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        # height=page.height - homebar.height,
        height=page.height,
        bgcolor=ft.colors.DEEP_PURPLE_100,
        image_src=f"/images/bgImage.png",
        image_fit=ft.ImageFit.COVER,
    )

    page.add(
        # homebar,
        homebg,
        ft.Container(
            content=ft.Container(
                content=ft.Markdown(
                    md_CldNet,
                    selectable=True,
                    extension_set=ft.MarkdownExtensionSet.GITHUB_WEB,
                    on_tap_link=lambda e: page.launch_url(e.data),
                    col=1,
                    expand=True,
                ),
                # margin=ft.margin.only(left=300, top=10, right=300, bottom=10),
                margin=ft.margin.symmetric(vertical=10, horizontal=20),
                padding=10,
                alignment=ft.alignment.center,
                bgcolor=ft.colors.RED_100,
                width=1000,
            ),
            margin=ft.margin.symmetric(vertical=0, horizontal=0),
            alignment=ft.alignment.center,
            bgcolor=ft.colors.WHITE10,
        ),
        ft.Container(
            ft.Row(
                [
                    ft.Text(
                        f"Copyright © 2013-{time.strftime('%Y', time.localtime())} by METhod Descriptor with Artifical Intelligence (METDAI)",
                        size=20,
                        color="black300",
                    ),
                    # ft.Image(
                    #     src=f"/icons/icon.png",
                    #     width=50,
                    #     height=50,
                    #     fit=ft.ImageFit.CONTAIN,
                    # ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
            ),
            bgcolor=ft.colors.PURPLE_600,
            height=60,
            alignment=ft.alignment.center,
        ),
    )

    def page_resize(e):
        print(
            f"New page size:",
            # f" {e.page.window_width}-{e.page.window_height}",
            f" {e.page.width}-{e.page.height}",
        )
        # homebg.height = e.page.height - homebar.height
        homebg.height = e.page.height
        page.update()

    page.on_resize = page_resize


ft.app(
    target=main,
    port=8000,
    view=ft.AppView.WEB_BROWSER,
    assets_dir="assets",
)
